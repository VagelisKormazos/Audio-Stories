package com.unipi.kormazos.unipi_audio_stories;

public interface SelectListener {
    void onItemClicked(Item item);
}
