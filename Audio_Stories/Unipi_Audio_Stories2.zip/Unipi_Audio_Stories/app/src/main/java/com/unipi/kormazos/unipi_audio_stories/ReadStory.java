package com.unipi.kormazos.unipi_audio_stories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReadStory extends AppCompatActivity {

    TextView userInput,insertTitle;
    MyTTS myTTS;
    ImageView imagePlay,imageStop,imageBack;
    String story;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_story);
        userInput = findViewById(R.id.textOfTheBook);
        insertTitle = findViewById(R.id.textViewTitle);

        myTTS = new MyTTS(this);
        int myInt = getIntent().getIntExtra("positionStory", 0);
        String storyTitle =getIntent().getStringExtra("theStory");
        insertTitle.setText(storyTitle);
        String storyText =getIntent().getStringExtra("theStoryText");

        imagePlay = findViewById(R.id.imageViewPlay);
        imagePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userInput.setVisibility(View.GONE);
                userInput.setText(storyText);
                //imagePlay.setImageResource(R.drawable.ic_baseline_pause_24);
                speak();
            }
        });

        imageStop = findViewById(R.id.imageViewPause);
        imageStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myTTS.stop();
            }
        });

        imageBack = findViewById(R.id.imageViewBack);
        imageBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myTTS.stop();
                Intent intent = new Intent(ReadStory.this ,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void speak(){
        if (!userInput.getText().toString().isEmpty()){
            //myTTS.speak(userInput.getText().toString());
            String message = userInput.getText().toString();
            int chunkSize = 100; // split the message into chunks of 100 characters
            int startIndex = 0;
            int endIndex = chunkSize;

            while (startIndex < message.length()) {
                if (endIndex > message.length()) {
                    endIndex = message.length();
                }
                String chunk = message.substring(startIndex, endIndex);
                myTTS.speak(chunk);
                startIndex += chunkSize;
                endIndex += chunkSize;
            }

        } else {
            Toast.makeText(this, "Please write a message", Toast.LENGTH_SHORT).show();
        }
    }
}